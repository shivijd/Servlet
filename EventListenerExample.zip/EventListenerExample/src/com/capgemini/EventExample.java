package com.capgemini;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class EventExample
 *
 */
@WebListener
public class EventExample implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public EventExample() {
       
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent arg0)  { 
            System.out.println("context destroyed");
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent event)  { 
    	Connection conn;
		try {
			
			  ServletContext context=event.getServletContext(); 
				String a =context.getInitParameter("drivername");
				try {
					Class.forName(a);
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
				String b = context.getInitParameter("url");
				  String c=context.getInitParameter("user");
				String d  =context.getInitParameter("password");
				conn = DriverManager.getConnection(b,c,d);				  
				context.setAttribute("myconnection", conn);
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
			
	
	}
  
    
	
    }

