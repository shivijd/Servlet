package com.capgemini;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyFirstServlet
 */
@WebServlet("/MyFirstServlet")
public class MyFirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyFirstServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		 int sum=0;
         int x,y;
         String a = request.getParameter("firstvalue");
         String b = request.getParameter("secondvalue");
         x = Integer.parseInt(a);
         y = Integer.parseInt(b);
         String select = request.getParameter("select");
         if("add".equals(select))
         {                 
         sum = x + y;
         
         }
         if("sub".equals(select))
         {
        	 sum=x-y;
        	 
         }
         if("mul".equals(select))
         {
        	 sum=x*y;
        	
         }
         if("divide".equals(select))
         {
        	 sum=x/y;        	
         }
         out.println("The sum is" + sum);
         }
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
