package com.param;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Parameter
 */
@WebServlet("/Parameter")
public class Parameter extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Parameter() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		PrintWriter out=response.getWriter();
//	        String[] games=request.getParameterValues("games");
//	        out.println("Selected Values...");    
//	        for(int i=0;i<games.length;i++)
//	       {
//	           out.println("<li>"+games[i]+"</li>");
//	       }

//		PrintWriter out = response.getWriter();  

//	  
//	   Enumeration<String> s = request.getHeaderNames();  
//	        while (s.hasMoreElements()) {  
//	        String headerName =  s.nextElement();  
//	        String headerValue = request.getHeader(headerName);  
//	        out.print("<b>"+headerName + "</b>: ");  
//	        out.println(headerValue + "<br>"); 
		Enumeration<String> en=request.getParameterNames();
		PrintWriter out = response.getWriter();  
		while(en.hasMoreElements())
		{
			Object obj=en.nextElement();
			String param=(String) obj;
			String value=request.getParameter("name");
			out.println("Parameter Name is '"+param+"' and Parameter Value is '"+value+"'");
		}		
	}

	}

